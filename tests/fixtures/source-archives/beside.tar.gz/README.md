# Pebble Sorter

Build with `npm ci && npm run build`.
