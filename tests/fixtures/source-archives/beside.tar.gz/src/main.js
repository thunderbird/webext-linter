import { sort } from "./lib/sort.js";
console.log(sort([3, 1, 2]));
